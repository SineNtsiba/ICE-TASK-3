/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package icetask3;

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author Bauba
 */
public class Question1 {
    public static void main(String[] args){
        String inputString = "([]{}[)";
        System.out.println(parenthesisChecker(inputString));
        /*
        char myChar;
        boolean status = true;
        for(int i = 0; i < username.length(); i++){
            myChar = username.charAt(i);
            if(Character.isAlphabetic(myChar) != true){
                System.out.println(myChar);
                System.out.println("You have non-alphabets in your username");
                status = false;
                break;
            }
        }
        if (status == true)
            System.out.println("Success");
        */
    }
    
    
    public static boolean parenthesisChecker(String expression){
        StringBuilder brackets = new StringBuilder(" ");
        int length = 0;
        char bracket;
        boolean valid = true;
        while(length <= expression.length()-1 && length >= 0){
            bracket = expression.charAt(length);
            if (bracket == '{' || bracket == '[' || bracket == '('){
                brackets.append(bracket);
            }
            else{
                switch(bracket){
                    case '}':
                        if (brackets.charAt(brackets.length()-1) == '{')
                            brackets.deleteCharAt(brackets.length()-1);
                        else
                            length = -2;
                        break;
                        
                    case ']':
                        if (brackets.charAt(brackets.length()-1) == '[')
                            brackets.deleteCharAt(brackets.length()-1);
                        else
                            length = -2;
                        break;
                    case ')':
                        if (brackets.charAt(brackets.length()-1) == '(')
                            brackets.deleteCharAt(brackets.length()-1);
                        else
                            length = -2;
                        break;
                    default:
                        System.out.println("Invalid input character " + bracket);
                        valid = false;
                        length = -2;
                }
            }
            System.out.println("Bracket to delete or add" + bracket);
            System.out.println(brackets);
            length++;
        }
        if(brackets.length() > 1)
            valid = false;
        return valid;
    }
    public boolean lengthChecker(String userName){
            return userName.length() >= 8 && userName.length() <= 20;
    }
}