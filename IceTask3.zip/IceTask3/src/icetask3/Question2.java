/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package icetask3;




import java.util.Iterator;
import java.util.List;
import java.util.ArrayList;
import java.util.Scanner;

public class Question2 {

    public static Iterable<Integer> oddSquaresSum(List<Integer> oddNumbers) {
        return () -> new Iterator<Integer>() {
            public int index = 0;
            public int sum = 0;

            @Override
            //https://stackoverflow.com/questions/36784602/implmentation-of-hasnext-method-in-an-inner-class-of-java
            public boolean hasNext() {
                return index < oddNumbers.size();
            }

            @Override
            public Integer next() {
                int currentOdd = oddNumbers.get(index);
                sum += currentOdd * currentOdd;
                index++;
                return sum;
            }
        };
    }

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        List<Integer> oddNumbers = new ArrayList<>();

        System.out.println("Enter odd numbers (enter a non-integer to stop):");

        //https://stackoverflow.com/questions/26566773/how-to-use-nextint-and-hasnextint-in-a-while-loop
        while (scanner.hasNextInt()) {
            int number = scanner.nextInt();
            if (number % 2 != 0) {
                oddNumbers.add(number);
            } else {
                System.out.println(number + " is not an odd number. Please enter only odd numbers.");
            }
        }

        System.out.println("Calculating sum of squares of the entered odd numbers...");

        for (int sum : oddSquaresSum(oddNumbers)) {
            System.out.println(sum);
        }

        scanner.close();
    }
}
