package icetask3;

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */


 import java.util.Scanner;

public class Question3 {
    public static int Question3(int a, int b) {
        //https://www.numerade.com/ask/question/int-gcdint-a-int-b-while-b-0-int-temp-b-b-a-b-a-temp-return-a-convert-this-function-to-macro-in-assembly-48121/
        while (b != 0) {
            int temp = b;
            b = a % b;
            a = temp;
        }
        return a;
    }

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        System.out.print("Enter the first number: ");
        int a = scanner.nextInt();

        System.out.print("Enter the second number: ");
        int b = scanner.nextInt();

        int gcd = Question3(a, b);
        System.out.println("The GCD of " + a + " and " + b + " is " + gcd);

        scanner.close();
    }
}
